package com.example.god;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.app.AlertDialog;
import android.view.View;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.FragmentActivity;

import com.google.android.gms.maps.*;
import com.google.android.gms.maps.model.*;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class MapActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private LatLng selectedLatLng;
    private String markerText = "";
    private Uri selectedImageUri;

    private ActivityResultLauncher<Intent> imagePickerLauncher;

    // 마커별 데이터 저장용 맵
    private Map<Marker, MyMarkerData> markerDataMap = new HashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        if (mapFragment != null) mapFragment.getMapAsync(this);

        // 사진 선택 결과 처리
        imagePickerLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                        Intent data = result.getData();
                        Uri imageUri = data.getData();
                        if (imageUri == null && data.getExtras() != null) {
                            // 카메라 촬영 후 Bitmap을 Uri로 변환 시도
                            Bitmap photo = (Bitmap) data.getExtras().get("data");
                            if (photo != null) {
                                selectedImageUri = Utils.getImageUri(this, photo);  // Utils 클래스 필요 (아래 참고)
                            }
                        } else {
                            selectedImageUri = imageUri;
                        }
                        addMarkerWithData();
                    } else {
                        Toast.makeText(this, "사진 선택 취소됨", Toast.LENGTH_SHORT).show();
                    }
                }
        );
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        mMap = googleMap;

        // 기본 위치 서울로 세팅
        LatLng seoul = new LatLng(37.5665, 126.9780);
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(seoul, 12));

        // 커스텀 InfoWindow Adapter 등록
        mMap.setInfoWindowAdapter(new GoogleMap.InfoWindowAdapter() {
            @Override
            public View getInfoWindow(Marker marker) {
                return null;  // 기본 프레임 사용
            }

            @Override
            public View getInfoContents(Marker marker) {
                View infoView = getLayoutInflater().inflate(R.layout.custom_info_window, null);
                TextView textView = infoView.findViewById(R.id.info_text);
                ImageView imageView = infoView.findViewById(R.id.info_image);

                MyMarkerData data = markerDataMap.get(marker);
                if (data != null) {
                    textView.setText(data.text);
                    try {
                        Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), data.imageUri);
                        imageView.setImageBitmap(bitmap);
                    } catch (IOException e) {
                        imageView.setImageResource(android.R.drawable.ic_menu_report_image);
                    }
                }
                return infoView;
            }
        });

        // 지도 클릭 시 텍스트 입력 대화상자 띄우기
        mMap.setOnMapClickListener(latLng -> {
            selectedLatLng = latLng;
            showTextInputDialog();
        });
    }

    private void showTextInputDialog() {
        final EditText input = new EditText(this);
        input.setHint("마커에 표시할 텍스트 입력");

        new AlertDialog.Builder(this)
                .setTitle("텍스트 입력")
                .setView(input)
                .setPositiveButton("다음", (dialog, which) -> {
                    markerText = input.getText().toString().trim();
                    if (!markerText.isEmpty()) {
                        showImageChoiceDialog();
                    } else {
                        Toast.makeText(this, "텍스트를 입력해주세요", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("취소", null)
                .show();
    }

    private void showImageChoiceDialog() {
        String[] options = {"사진 찍기", "갤러리에서 선택"};
        new AlertDialog.Builder(this)
                .setTitle("사진 추가 방법 선택")
                .setItems(options, (dialog, which) -> {
                    if (which == 0) {
                        takePhoto();
                    } else {
                        pickImageFromGallery();
                    }
                })
                .show();
    }

    private void pickImageFromGallery() {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        imagePickerLauncher.launch(intent);
    }

    private void takePhoto() {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        imagePickerLauncher.launch(intent);
    }

    // 마커를 생성하고 데이터 저장 후 화면에 표시
    private void addMarkerWithData() {
        if (selectedLatLng == null || markerText.isEmpty() || selectedImageUri == null) {
            Toast.makeText(this, "마커 정보가 완전하지 않습니다.", Toast.LENGTH_SHORT).show();
            return;
        }

        Marker marker = mMap.addMarker(new MarkerOptions()
                .position(selectedLatLng)
                .title(markerText));

        // 마커 클릭 시 InfoWindow 보여주기
        if (marker != null) {
            markerDataMap.put(marker, new MyMarkerData(markerText, selectedImageUri));
            marker.showInfoWindow();
            Toast.makeText(this, "마커 추가 완료", Toast.LENGTH_SHORT).show();
        }

        // 다음 입력을 위해 초기화
        selectedLatLng = null;
        markerText = "";
        selectedImageUri = null;
    }

    // 마커 텍스트 + 사진 저장용 클래스
    private static class MyMarkerData {
        String text;
        Uri imageUri;

        MyMarkerData(String text, Uri imageUri) {
            this.text = text;
            this.imageUri = imageUri;
        }
    }
}
